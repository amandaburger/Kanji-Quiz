//
//  Question.swift
//  Quizzler
//
//  Created by Amanda Burger on 5/20/18.
//  Copyright © 2018 London App Brewery. All rights reserved.
//

import Foundation
//for a class, the name must be capital
//every question will wither be true or falso
//the class is the bluePrint for the object,
class Question  {
    let questionTxt :String
    let an1 : String
    let an2: String
    let an3: String
    let an4: String
    let answer: Int
    //the constants for the class are "the proporties of a class , every class or "object" will have these proporties)
    //functions in a class are a method, they only portain to the class
    
    // the initializer will set the properties(constants of the class) whenever a new instance of the class is created
    //the parameters are just like parameters in a funcion
    init(text: String, a1: String, a2: String, a3: String, a4: String, correctAnswer: Int){
        questionTxt=text
        an1 = a1;
        an2 = a2;
        an3 = a3;
        an4 = a4;
        answer = correctAnswer;
        
        
    }
    
}

