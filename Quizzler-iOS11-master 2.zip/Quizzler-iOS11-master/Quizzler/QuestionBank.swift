//
//  QuestionBank.swift
//  Quizzler
//
//  Created by Amanda Burger on 5/20/18.
//  Copyright © 2018 London App Brewery. All rights reserved.
//

import Foundation

class QuestionBank {
    var list = [Question]()
    init(){
        // Creating a quiz item and appending it to the list
        let item = Question(text: "力", a1: "power", a2: "tree", a3: "bamboo", a4: "male", correctAnswer: 1)
        
        // Add the Question to the list of questions
        list.append(item)
        
        // skipping one step and just creating the quiz item inside the append function
        list.append(Question(text: "町", a1: "forest", a2: "village", a3: "bamboo", a4: "use", correctAnswer: 2));
        
        list.append(Question(text: "白", a1: "grass", a2: "white", a3: "stone", a4: "enter", correctAnswer: 2));
        
        list.append(Question(text: "田", a1: "year", a2: "arm", a3: "leg", a4: "rice field", correctAnswer: 4));
        
        list.append(Question(text: "早", a1: "early", a2: "young", a3: "before", a4: "heavens", correctAnswer: 1));
        list.append(Question(text: "正", a1: "life", a2: "forest", a3: "correct", a4: "happy", correctAnswer: 3));
    }
    
}
