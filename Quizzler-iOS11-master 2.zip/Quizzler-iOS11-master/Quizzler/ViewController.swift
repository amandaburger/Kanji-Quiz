//
//  ViewController.swift
//  Quizzler
//
//  Created by Angela Yu on 25/08/2015.
//  Copyright (c) 2015 London App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let allQuestions = QuestionBank()
    var pickedAns : Int = 1
    var questionNumber : Int = 0
    var score : Int = 0
    
    
    //Place your instance variables here
    
    @IBOutlet weak var a1: UILabel!
    
    @IBOutlet weak var a4: UILabel!
    @IBOutlet weak var a3: UILabel!
    @IBOutlet weak var a2: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet var progressBar: UIView!
    @IBOutlet weak var progressLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nextQuestion()
        
    }
    
    


    @IBAction func answerPressed(_ sender: AnyObject) {
        if sender.tag == 1 {
            pickedAns = 1
            
        }
        else if sender.tag == 2 {
            pickedAns = 2
        }
        else if sender.tag == 3 {
            pickedAns = 3
            
        }
        else if sender.tag == 4 {
            pickedAns = 4
        }
        checkAnswer()
        questionNumber = questionNumber+1
        
        nextQuestion()
  
    }
    
    
    func updateUI() {
        scoreLabel.text = ("score:"+"\(score)")
        progressLabel.text = ("\(questionNumber + 1)" + "/6")
        progressBar.frame.size.width = (view.frame.size.width/13) * CGFloat(questionNumber+1)
    
      
    }
    

    func nextQuestion() {
        if questionNumber <= 5 {
            questionLabel.text = allQuestions.list[questionNumber].questionTxt
            a1.text = allQuestions.list[questionNumber].an1
            a2.text = allQuestions.list[questionNumber].an2
            a3.text = allQuestions.list[questionNumber].an3
            a4.text = allQuestions.list[questionNumber].an4
            
            updateUI()
        }
        else{
            let alert = UIAlertController(title: "yay", message: "you finished the questions", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "restart", style: .default, handler:
            { (UIAlertAction) in
                self.startOver()
            })
            let cancelAction = UIAlertAction(title: "cancel", style: .default, handler: nil)
            alert.addAction(restartAction)
            alert.addAction(cancelAction)
            present(alert, animated: true, completion: nil)
        }
    }
    
    
    func checkAnswer() {
        let correctAnswer = allQuestions.list[questionNumber].answer
        
        if pickedAns == correctAnswer{
            ProgressHUD.showSuccess("correct")
            
            score += 1
            
        }
        else{
            print("wrong")
            ProgressHUD.showError("wrong")
        }
        
        
        
    }
    
    
    func startOver() {
        questionNumber = 0
        nextQuestion()
        score=0
       
    }
    

    
}
